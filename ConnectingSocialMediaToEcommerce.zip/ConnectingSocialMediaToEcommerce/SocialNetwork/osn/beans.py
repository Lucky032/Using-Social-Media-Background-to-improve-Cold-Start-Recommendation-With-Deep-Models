
class PostBean:

    def __init__(self,post,comments,likes,dislikes):

        self.post=post
        self.comments=comments
        self.likes=likes
        self.dislikes=dislikes
